module.exports = {
    plugins: {
        'postcss-cssnext': {}
    }
}